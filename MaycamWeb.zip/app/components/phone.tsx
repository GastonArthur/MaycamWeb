import { Phone } from "lucide-react"

export default function PhoneIcon() {
  return <Phone className="h-5 w-5 text-violet-500 mr-3" />
}

